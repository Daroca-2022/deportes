import React, { Component } from "react";

class PageDeportes extends Component{
    render(){
        return <h1>Página Deportes</h1>
    }
}

export default PageDeportes