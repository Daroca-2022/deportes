import React, { Component } from "react";

class PageEquipos extends Component{
    render(){
        return <h1>Página Equipos</h1>
    }
}

export default PageEquipos