import React, { Component } from "react";

class PageEventos extends Component{
    render(){
        return <h1>Página Eventos</h1>
    }
}

export default PageEventos