import React, { Component } from "react";

class PageInicio extends Component{
    render(){
        return <h1>Página Inicio</h1>
    }
}

export default PageInicio