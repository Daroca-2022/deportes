import React, { Component } from "react";

class PageUsuarios extends Component{
    render(){
        return <h1>Página Usuarios</h1>
    }
}

export default PageUsuarios