import React from "react"


function Saludar(props){
    return <div>
      <h1>{props.title}</h1>
      </div>
  }

export default Saludar